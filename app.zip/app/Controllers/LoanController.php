<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\LoanRepository;
use PDO;

class LoanController extends BaseController
{
    private LoanRepository $loans;

    public function __construct(PDO $db)
    {
        parent::__construct($db);
        $this->loans = new LoanRepository($db);
    }

    /**
     * GET /api/loans
     */
    public function index(): never
    {
        $branchId = $this->getQuery('branchId');
        $status   = $this->getQuery('status');
        $memberId = $this->getQuery('memberId');

        $result = $this->loans->all($branchId, $status, $memberId);
        $this->json([
            'success' => true,
            'data'    => $result,
            'total'   => count($result)
        ]);
    }

    /**
     * GET /api/loans/:id
     */
    public function show(string $id): never
    {
        $loan = $this->loans->find($id);
        if (!$loan) {
            $this->error('Loan record not found', 404);
        }

        $this->success($loan);
    }

    /**
     * GET /api/loans/:id/schedule
     */
    public function schedule(string $id): never
    {
        $schedule = $this->loans->getSchedule($id);
        $this->success($schedule);
    }

    /**
     * POST /api/loans/calculate-schedule
     */
    public function calculateSchedule(): never
    {
        $input = $this->getRequestBody();
        $principal = (float)($input['principal_amount'] ?? $input['principal'] ?? 0);
        $rate = (float)($input['annual_interest_rate'] ?? $input['interest_rate'] ?? 0);
        $term = (int)($input['term_months'] ?? 12);
        $method = $input['interest_calculation_method'] ?? 'Diminishing Balance';
        $startDate = $input['disbursement_date'] ?? date('Y-m-d');
        $frequency = $input['payment_frequency'] ?? 'Monthly';

        if ($principal <= 0 || $term <= 0) {
            $this->error('Valid principal amount and term months are required.', 422);
        }

        $schedule = \App\Services\AmortizationService::generateSchedule(
            $principal,
            $rate,
            $term,
            $method,
            $startDate,
            $frequency
        );

        $totalInterest = array_sum(array_column($schedule, 'interest'));
        $totalPayment = array_sum(array_column($schedule, 'total_installment'));

        $this->json([
            'success'  => true,
            'schedule' => $schedule,
            'summary'  => [
                'principal'     => $principal,
                'total_interest'=> round($totalInterest, 2),
                'total_payment' => round($totalPayment, 2),
                'installments'  => count($schedule)
            ]
        ]);
    }
    /**
     * Update Loan Status
     * PUT /api/loans/:id
     */
    public function updateLoanStatus(string $id):array
    {
        $status = $this->getRequestBody();
        $result = $this->loans->updateStatus($id, $status);
        // return ['status'=>$this->getRequestBody()];
        return $this->success($result,'success');
        
    }
    /**DELETED MEHTODS apply() & originate() */

    /**
     * POST /api/loans/:id/repay
     * POST /api/loans/repay
     */
    public function repay(?string $id = null): never
    {
        $input = $this->getRequestBody();
        if ($id) {
            $input['loan_id'] = $id;
        }

        if (empty($input['loan_id'])) {
            $this->error('Loan ID is required for repayment.', 422);
        }

        if (empty($input['amount_paid']) && !empty($input['amount'])) {
            $input['amount_paid'] = $input['amount'];
        }

        if (empty($input['amount_paid']) || (float)$input['amount_paid'] <= 0) {
            $this->error('A valid positive repayment amount is required.', 422);
        }

        try {
            $receipt = $this->loans->recordPayment($input);
            $this->success($receipt, 'Loan payment recorded and allocated successfully.');
        } catch (\Exception $e) {
            $this->error('Loan payment processing failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/loans
     */
    
    public function store(?array $requestInput = null): never
    {
        $input = $requestInput ?? $this->getRequestBody();

        if (empty($input['branch_id'])) {
            $this->error('Branch is required.', 422);
        }
        if (empty($input['disbursed_from_cash_account_id']) && empty($input['cash_account_id'])) {
            $this->error('Disbursement cash account is required.', 422);
        }
        $input['disbursed_from_cash_account_id'] = $input['disbursed_from_cash_account_id']
            ?? $input['cash_account_id'];

        if (empty($input['first_due_date'])) {
            $input['first_due_date'] = (new \DateTime($input['disbursement_date'] ?? 'now'))
                ->modify('+1 month')->format('Y-m-d');
        }

        if (empty($input['maturity_date'])) {
            $input['maturity_date'] = (new \DateTime($input['first_due_date']))
                ->modify('+' . max(0, (int)($input['term_months'] ?? 12) - 1) . ' months')
                ->format('Y-m-d');
        }

        if (empty($input['payment_frequency'])) {
            $input['payment_frequency'] = 'Monthly';
        }

        if (!isset($input['net_disbursed'])) {
            $principal = (float)($input['principal_amount'] ?? 0);
            $processingFee = (float)($input['processing_fee'] ?? 0);
            $serviceFee = (float)($input['service_fee'] ?? 0);
            $input['net_disbursed'] = max(0, $principal - $processingFee - $serviceFee);
        }

        $this->persistLoan($input);
    }

    private function persistLoan(array $input): never
    {
        if (empty($input['member_id']) || empty($input['loan_product_id']) || empty($input['principal_amount'])) {
            $this->error('Member, Loan Product, and Principal Amount are required.', 422);
        }

        try {
            $loan = $this->loans->createLoan($input);
            $this->success($loan, 'Loan disbursed and amortization schedule initialized successfully.', 201);
        } catch (\Exception $e) {
            $this->error('Loan disbursement failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/loans/payments
     */
    public function payment(): never
    {
        $input = $this->getRequestBody();

        if (empty($input['loan_id']) || empty($input['amount_paid']) || (float)$input['amount_paid'] <= 0) {
            $this->error('Loan ID and a positive payment amount are required.', 422);
        }

        try {
            $receipt = $this->loans->recordPayment($input);
            $this->success($receipt, 'Loan payment recorded and allocated successfully.');
        } catch (\Exception $e) {
            $this->error('Loan payment processing failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * DELETE /api/loans/:id
     */
    public function destroy(string $id): never
    {
        $deleted = $this->loans->delete($id);
        if (!$deleted) {
            $this->error('Failed to delete loan.', 400);
        }

        $this->success(['id' => $id], 'Loan deleted successfully.');
    }
    /**
     * NEW UPDATED METHODS
     */
    public function apply(): never
    {
        $input = $this->getRequestBody();

        if (empty($input['member_id'])) {
            $this->error('Member is required.', 422);
        }

        if (empty($input['loan_product_id'])) {
            $this->error('Loan Product is required.', 422);
        }

        if (empty($input['branch_id'])) {
            $this->error('Branch is required.', 422);
        }

        if (empty($input['principal_amount'])) {
            $this->error('Loan amount is required.', 422);
        }

        try {
            
            $application = $this->loans->createApplication($input);

            $this->success(
                $application,
                'Loan application submitted successfully.',
                201
            );
        } catch (\Throwable $e) {
            $this->error(
                'Loan application failed: ' . $e->getMessage(),
                500
            );
        }
    }


    /**
     * POST /api/loans/applications/approve
     *
     * Approve an existing loan application.
     *
     * This DOES NOT disburse money.
     */
    public function approveApplication(): never
    {
        $input = $this->getRequestBody();

        if (empty($input['application_id'])) {
            $this->error('Loan application is required.', 422);
        }

        if (empty($input['approved_amount'])) {
            $this->error('Approved amount is required.', 422);
        }

        try {
            $application = $this->loans->approveApplication($input);

            $this->success(
                $application,
                'Loan application approved successfully.',
                200
            );
        } catch (\Throwable $e) {
            $this->error(
                'Loan approval failed: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * GET /api/loans/applications
     */
    public function applications(): never
    {
        $branchId = $_POST['branchId'] ?? null;
        $status = $_POST['status'] ?? null;
        $memberId = $_POST['memberId'] ?? null;
        // print_r($memberId);

        try {
            $apps = $this->loans->allApplications($branchId, $status, $memberId);
            $this->success($apps);
        } catch (\Throwable $e) {
            $this->error('Failed to load loan applications: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/loans/applications/reject
     */
    public function rejectApplication(): never
    {
        $input = $this->getRequestBody();

        if (empty($input['application_id']) && empty($input['id'])) {
            $this->error('Loan application ID is required.', 422);
        }
        $input['application_id'] = $input['application_id'] ?? $input['id'];

        try {
            $app = $this->loans->rejectApplication($input);
            $this->success($app, 'Loan application rejected successfully.');
        } catch (\Throwable $e) {
            $this->error('Rejecting loan application failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/loans/originate
     *
     * Disburse an approved loan application.
     */
    public function originate(): never
    {
        $input = $this->getRequestBody();

        if (empty($input['application_id'])) {
            $this->error('Loan application is required.', 422);
        }

        if (
            empty($input['disbursed_from_cash_account_id']) &&
            empty($input['cash_account_id'])
        ) {
            $this->error(
                'Disbursement cash account is required.',
                422
            );
        }

        $input['disbursed_from_cash_account_id']
            = $input['disbursed_from_cash_account_id']
            ?? $input['cash_account_id'];

        try {
            $loan = $this->loans->disburseLoan($input);

            $this->success(
                $loan,
                'Loan disbursed and amortization schedule initialized successfully.',
                201
            );
        } catch (\Throwable $e) {
            $this->error(
                'Loan disbursement failed: ' . $e->getMessage(),
                500
            );
        }
    }
}
